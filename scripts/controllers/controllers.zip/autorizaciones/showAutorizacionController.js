'use strict';
angular.module('GenesisApp')
    .controller('showAutorizacionController', ['$scope', '$http', function ($scope, $http) {


    }])
