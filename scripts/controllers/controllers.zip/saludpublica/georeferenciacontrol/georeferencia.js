'use strict';
angular.module('GenesisApp').controller('georeferenciacontrolController', ['$scope', '$http', function ($scope, $http) {
    console.log("georeferenciacontrolController");
}]);