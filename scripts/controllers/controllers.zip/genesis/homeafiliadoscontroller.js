'use strict';
angular.module('GenesisApp').controller('inicioafiliadosController', ['$scope', function ($scope) {
    $scope.test = "inicioafiliadosController";
}])
