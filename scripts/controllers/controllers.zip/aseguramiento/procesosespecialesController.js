'use strict';
angular.module('GenesisApp')
  .controller('procesosespecialesController', ['$scope', '$http',
    function ($scope, $http) {

        $scope.tipodeItem = 0;
        $scope.Rol_Cedula = sessionStorage.getItem('cedula');
        $scope.rolcod = sessionStorage.getItem('rolcod');

      $(document).ready(function () {
        $scope.obtener_token();
        $scope.obtenerreporte();
        $scope.obtener_correo();

        console.log($(window).width());
        if ($(window).width() < 1100) {
          document.querySelector("#pantalla").style.zoom = 0.7;
        }
        if ($(window).width() > 1100 && $(window).width() < 1300) {
          document.querySelector("#pantalla").style.zoom = 0.7;
        }
        if ($(window).width() > 1300 && $(window).width() < 1500) {
          document.querySelector("#pantalla").style.zoom = 0.8;
        }
        if ($(window).width() > 1500) {
          document.querySelector("#pantalla").style.zoom = 0.9;
        }
        document.querySelector("#content").style.backgroundColor = "white";
        
        //////////////////////////////////////////////////////////
      });

      $scope.obtener_token = function () {
        $http({
           method: 'POST',
           url: "php/financiera/reportes/funcreportes.php",
           data: {
              function: 'obtener_token'
           }
        }).then(function (response) {
           $scope.respuestat = response.data;
        });
     }

     $scope.obtener_correo = function () {
        $http({
           method: 'POST',
           url: "php/financiera/reportes/funcreportes.php",
           data: {
              function: 'obtener_correo', codigoc: $scope.Rol_Cedula
           }
        }).then(function (response) {
           $scope.correo = response.data.Correo;
           $scope.respuestac = response.data;
        });
     }

      $scope.obtenerreporte = function () {
          console.log($scope.rolcod);
        $http({
           method: 'POST',
           url: "php/informes/obtenerreportes.php",
           data: { function: 'obtenerreportes', v_prol: $scope.rolcod }
        }).then(function (response) {
           $scope.Reportes = response.data;
        })
     }

      $scope.SeleccionarItem = function () {
        if ($scope.tipodeItem == "0") {
           $scope.vercontenido = false;
        } else {
           $scope.ocultartodo();
           $scope.vercontenido = true;
           switch ($scope.tipodeItem) {
                case "67":
                   $scope.contenido1 = true;
                   $scope.contenido2 = false;
               break;
              case "2":
                $scope.contenido1 = false;
                $scope.contenido2 = true;
                 break;
           }
        }
     }
   
     $scope.ocultartodo = function () {
        $scope.contenido1 = false;
        $scope.contenido2 = false;
     }

     $scope.Cargue_BDUA = function () {
        var datosRC = {
            "correo": $scope.correo
         }
        swal({
          title: '¿Desea Generar Proceso BDUA?',
          text: "Generar Proceso",
          type: 'info',
          showCancelButton: true,
          confirmButtonText: "Confirmar",
          cancelButtonText: "Cancelar",
          cancelButtonColor: "#d33",
          allowOutsideClick: false
        }).then(function (result) {
          if (result) {
            swal({
                html: '<div class="loading"><div class="default-background"></div><div class="default-background"></div><div class="default-background"></div></div><p style="font-weight: bold;">Cargando...</p>',
                width: 200,
                allowOutsideClick: false,
                allowEscapeKey: false,
                showConfirmButton: false,
                animation: false
             });
            $http({
              method: 'POST',
              url: "php/financiera/reportes/funcreportes.php",
              data: {
                function: 'Cargue_BDUA',
                datos: (datosRC)
              }
            }).then(function (response) {
                  swal({
                    title: "Mensaje",
                    text: "Generando reporte en segundo plano, cuando termine de cargar, la información será generada a su correo corporativo",
                    type: "success",
                  })
                  $scope.respuestata = response.data;
            });
          }
        }).catch(swal.noop);
     }



      $(window).on('resize', function () {
        if ($(window).width() < 1100) {
          document.querySelector("#pantalla").style.zoom = 0.7;
        }
        if ($(window).width() > 1100 && $(window).width() < 1300) {
          document.querySelector("#pantalla").style.zoom = 0.7;
        }
        if ($(window).width() > 1300 && $(window).width() < 1500) {
          document.querySelector("#pantalla").style.zoom = 0.8;
        }
        if ($(window).width() > 1500) {
          document.querySelector("#pantalla").style.zoom = 0.9;
        }
      });

    }]);
