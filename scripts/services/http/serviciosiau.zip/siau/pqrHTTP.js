'use strict';
/**
* @ngdoc service
* @name GenesisApp.service:pqrHttp
* @description
* # servicio http para el llamado al web services de todos los procedimientos del pqr.*/
angular.module('GenesisApp')
  .service('pqrHttp', function ($http, $q) {
    return ({
      /* Functions Radicación PQRS */
      getPrivideliosPQR: function () {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerPrivilegios' }
        });
        return (request.then(handleSuccess, handleError));
      },
      getSolicitud: function () {
        var request = $http({
          method: "get",
          url: "json/solicitud.json"
        });
        return (request.then(handleSuccess, handleError));
      },
      getRiesgo: function () {
        var request = $http({
          method: "get",
          url: "json/riesgo.json"
        });
        return (request.then(handleSuccess, handleError));
      },
      getMediosRecepcion: function () {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerMediosRecepcion' }
        });
        return (request.then(handleSuccess, handleError));
      },
      getOtrosEntesDeControl: function () {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerEntesControl' }
        });
        return (request.then(handleSuccess, handleError));
      },
      getEntidades: function (data) {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerEntidades', entidad: data }
        });
        return (request.then(handleSuccess, handleError));
      },
      getRadicacion: function () {
        var request = $http({
          method: "get",
          url: "json/radicacion.json"
        });
        return (request.then(handleSuccess, handleError));
      },
      getDocumento: function () {
        var request = $http({
          method: "get",
          url: "json/tipodocumento.json"
        });
        return (request.then(handleSuccess, handleError));
      },
      getSexo: function () {
        var request = $http({
          method: "get",
          url: "json/sexo.json"
        });
        return (request.then(handleSuccess, handleError));
      },
      getCriteriObjetivo: function () {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerCriteriObjetivos' }
        });

        return (request.then(handleSuccess, handleError));
      },
      getCriterioSubjetivo: function () {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerCriterioSubjetivos' }
        });
        return (request.then(handleSuccess, handleError));
      },
      getCriterioComplementario: function () {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerCriterioComplementario' }
        });
        return (request.then(handleSuccess, handleError));
      },
      buscarpqrs: function (documento) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Rpqr.php",
          data: { function:'buscarpqr',pqr:documento}
        });
        return (request.then(handleSuccess, handleError));
      }, 
      detallepqrs: function (codigo) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Rpqr.php",
          data: { function:'detallepqr',pqr:codigo}
        });
        return (request.then(handleSuccess, handleError));
      },
      getSujetosproteccionespecial: function () {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerSujetos' }
        });
        return (request.then(handleSuccess, handleError));
      },
      getServicios: function () {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerServicios' }
        });
        return (request.then(handleSuccess, handleError));
      },
      getMedicamentos: function () {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerMedicamentos' }
        });
        return (request.then(handleSuccess, handleError));
      },
      getAcudiente: function () {
        var request = $http({
          method: "get",
          url: "json/acudiente.json"
        });
        return (request.then(handleSuccess, handleError));
      },
      getMacromotivos: function () {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerMacromotivos' }
        });
        return (request.then(handleSuccess, handleError));
      },
      getMotivosGenerales: function () {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerMotivosGenerales' }
        });
        return (request.then(handleSuccess, handleError));
      },
      getMotivosEspecificos: function () {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerMotivosEspecificos' }
        });
        return (request.then(handleSuccess, handleError));
      },
      getDias: function () {
        var request = $http({
          method: "get",
          url: "json/dias.json"
        });
        return (request.then(handleSuccess, handleError));
      },
      getRespuestas: function () {
        var request = $http({
          method: "get",
          url: "json/respuestapqr.json"
        });
        return (request.then(handleSuccess, handleError));
      },
      getDepartamentosMunicipios: function () {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerDepartamentosMunicipios' }
        });
        return (request.then(handleSuccess, handleError));
      },
      getSession: function () {
        var request = $http({
          method: "get",
          url: "php/obtenersession.php"
        });
        return (request.then(handleSuccess, handleError));
      },
      postSearchAfiliado: function (data) {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'searchAfiliado', tipodocumento: data.selectedDocumento, documento: data.documento, tipo: data.tipo }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      postSearchIps: function (data) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'searchIps', ips: data }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      postPqr: function (data, file, num, tipo) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Cpqr.php",
          data: { function: 'insertarDatosPqr', pqr: data, pqrFile: file, numero: num, action: tipo }
        });
        return (request.then(handleSuccessPost, handleError));
      },

      /* Functions Admon PQRS */
      getMotivosAseguramiento: function () {
        var request = $http({
          method: "get",
          url: "json/movitos_aseguramiento.json"
        });
        return (request.then(handleSuccess, handleError));
      },
      getCausales: function () {
        var request = $http({
          method: "get",
          url: "json/causales.json"
        });
        return (request.then(handleSuccess, handleError));
      },
      get_TiposCausales: function () {
        var request = $http({
          method: "get",
          url: "json/tipos_causales.json"
        });
        return (request.then(handleSuccess, handleError));
      },
      getSubTiposCausales: function () {
        var request = $http({
          method: "get",
          url: "json/sub_tipos_causales.json"
        });
        return (request.then(handleSuccess, handleError));
      },
      getAccionesTraslado: function () {
        var request = $http({
          method: "get",
          url: "json/acciones_traslados.json"
        });
        return (request.then(handleSuccess, handleError));
      },
      getRespuestaTraslado: function () {
        var request = $http({
          method: "get",
          url: "json/respuesta_traslados.json"
        });
        return (request.then(handleSuccess, handleError));
      },
      getPQRS: function (state) {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerPQRS', estado: state }
        });
        return (request.then(handleSuccess, handleError));
      },
      postSearchUsuarios: function (data) {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerListados', coincidencia: data }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      postSearchIps: function (data) {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'searchIps', ips: data }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      getResponsables: function () {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerResponsables' }
        });
        return (request.then(handleSuccess, handleError));
      },
      postAseguramientoPqr: function (data) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Cpqr.php",
          data: { function: 'insertarDatosPqrAseguramiento', aseguramiento: data }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      postResponsablePqr: function (data, num, tipo) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Cpqr.php",
          data: { function: 'saveResponsablePqrSalud', responsable: data, numero: num, action: tipo }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      postReasignarResponsablePqr: function (res, num) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Cpqr.php",
          data: { function: 'reasignarResponsable', responsable: res, pqr: num }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      postResponsableSeleccionables: function (data, state) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Cpqr.php",
          data: { function: 'saveResponsableSeleccionables', responsable: data, estado: state }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      postCrudSalud: function (codpqr, cedula, coment, state, adj, ext, step, mnegacion, adelegada, ngacion) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Cpqr.php",
          data: { function: 'insertSalud', pqr: codpqr, responsable: cedula, comentario: coment, estado: state, adjunto: adj, extension: ext, fase: step, motivonegacion: mnegacion, areadelegadanegacion: adelegada, negacion: ngacion }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      getResponsablesPQR: function (codpqr) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerResponsablesPQR', pqr: codpqr }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      getNegacionPQR: function (codpqr) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerNegacionPQR', pqr: codpqr }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      getProcesoSaludPQR: function (codpqr) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerProcesoSaludPQR', pqr: codpqr }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      getGestionFaseActualSaludPQR: function (codpqr, pfase) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerFaseActual', pqr: codpqr, fase: pfase }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      getGestionxFaseSaludPQR: function (codpqr, pfase) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerGestionXFase', pqr: codpqr, fase: pfase }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      getInfoAseguramientoPQR: function (codpqr) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerPQRaseguramiento', pqr: codpqr }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      getGestionAseguramientoPQR: function (codpqr) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerGestionPQRaseguramiento', pqr: codpqr }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      dowloadfile: function (ruta) {
        var request = $http({
          method: 'POST',
          url: "php/juridica/tutelas/functutelas.php",
          data: { function: 'descargaAdjunto', ruta: ruta }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      getMotivosNegacion: function () {
        var request = $http({
          method: "get",
          url: "json/motivos_negacion.json"
        });
        return (request.then(handleSuccess, handleError));
      }, postViewNotification: function (codpqr) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Cpqr.php",
          data: { function: 'insertViewNotification', pqr: codpqr }
        });
        return (request.then(handleSuccessPost, handleError));
      },//===============ADMINISTRACION PARAMETROS============================
      getRegimen: function () {
        var request = $http({
          method: "get",
          url: "json/regimen.json"
        });
        return (request.then(handleSuccess, handleError));
      },
      getSede: function () {
        var request = $http({
          method: "get",
          url: "json/sede.json"
        });
        return (request.then(handleSuccess, handleError));
      },
      postObtenerParametro: function (rv, reg, sed, ent, med) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerParametro', riesgo: rv, regimen: reg, sede: sed, ente: ent, medio: med }
        });
        return (request.then(handleSuccessPost, handleError));
      },

      postObtenerMotivos: function (cod) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerMotivosXparametro', codigo: cod }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      postObteneResponsable: function (res) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerResponsable', responsable: res }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      postUpdateResponsableMotivo: function (resn, resa, mot, param) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Cpqr.php",
          data: { function: 'updateResponsableMotivo', resnuevo: resn, resanterior: resa, motivo: mot, parametro: param }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      postUpdateMotivosResponsable: function (resn, resa, param) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Cpqr.php",
          data: { function: 'updateMotivosResponsable', resnuevo: resn, resanterior: resa, parametro: param }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      postObtenerResponsablesMotivos: function (param) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerResponsableMotivos', 'parametro': param }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      postObtenerMotivosResponsable: function (res, param) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerMotivosResponsable', 'responsable': res, 'parametro': param }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      postObtenerResponsablesSeccionales: function () {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerResponsablesSeccionales' }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      postUpdateResponsableSeccional: function (resn, resa, param) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Cpqr.php",
          data: { function: 'updateResponsableSeccional', resnuevo: resn, resanterior: resa, parametro: param }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      postCarguePqr: function (data) {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Cpqr.php",
          data: { function: 'cargeMasivoPqr', pqr: data }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      postObtenerPqrExcel: function () {
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'obtenerPqrExcel' }
        });
        return (request.then(handleSuccessPost, handleError));
      },
      postPQRSuperSalud: function (data) {
        console.log(data.criterioobjetivo);
        var request = $http({
          method: 'POST',
          url: "php/siau/pqr/Cpqr.php",
          data: {
            function: 'updatePQRSuperSalud', criterioobjetivo: data.criterioobjetivo,
            criteriosubjetivo: data.criteriosubjetivo,
            critericomplementario: data.critericomplementario,
            sujetosproteccionespecial: data.sujetosproteccionespecial,
            servicios: data.servicios,
            medicamentos: data.medicamentos,
            pqrfile: data.pqrfile,
            pqrfileFtp: data.pqrfileFtp,
            codigosuper: data.codigosuper,
            extension: data.extension,
            adjunto: data.adjunto,
            reporta: data.reporta
          }
        });
        return (request.then(handleSuccessPost, handleError));
      }, p_mostrar_traza: function (pqr) {
        var request = $http({
          method: "POST",
          url: "php/siau/pqr/Rpqr.php",
          data: { function: 'p_mostrar_traza', pqr: pqr }
        });
        return (request.then(handleSuccess, handleError));
      }

    })

    function handleSuccessPost(response) {
      return (response);
    }
    function handleSuccess(response) {
      return (response.data);
    }
    function handleError(error) {
      if (error == null) {
        return ($q.reject(error));
      } else if (error.errorMessage !== undefined) {
        return ($q.reject(error.errorMessage));
      } else {
        return ($q.reject(error.ExceptionMessage));
      }
    }
  });
