<?php
	$postdata = file_get_contents("php://input");
  $request = json_decode($postdata);
	$function = $request->function;
	$function();

  function obtenerServicios(){
    require_once('../../config/dbcon.php');
    global $request;
		$contrato = $request->contrato;
    $tipo = $request->tipo;
    $consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_OBTENER_SERVICIO(:v_pcontrato,:v_ptipo,:v_json_row); end;');
		oci_bind_by_name($consulta,':v_pcontrato',$contrato);
    oci_bind_by_name($consulta,':v_ptipo',$tipo);
    $clob = oci_new_descriptor($c,OCI_D_LOB);
    oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
    oci_execute($consulta,OCI_DEFAULT);
    if (isset($clob)) {
      $json = $clob->read($clob->size());
      echo $json;
    }else{
      echo 0;
    }
    oci_close($c);
  }
  function obtenerContratos(){
    require_once('../../config/dbcon.php');
    global $request;
    $nit = $request->nit;
    $regimen = $request->regimen;
    $consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_OBTENER_CONTRATO(:v_ptercero,:v_pregimen,:v_json_row); end;');
    oci_bind_by_name($consulta,':v_ptercero',$nit);
    oci_bind_by_name($consulta,':v_pregimen',$regimen);
    $clob = oci_new_descriptor($c,OCI_D_LOB);
    oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
    oci_execute($consulta,OCI_DEFAULT);
    if (isset($clob)) {
      $json = $clob->read($clob->size());
      echo $json;
    }else{
      echo 0; 
    }
    oci_close($c);
  }
  function obtenerDiagnostico(){
    require_once('../../config/dbcon.php');
    global $request;
    $codigo = $request->codigo;
    $sexo = $request->sexo;
    $edad = $request->edad;
    $consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_OBTENER_DIAGNOSTICO(:v_pcie10,:v_psexo,:v_pedad,:v_json_row); end;');
    oci_bind_by_name($consulta,':v_pcie10',$codigo);
    oci_bind_by_name($consulta,':v_psexo',$sexo);
    oci_bind_by_name($consulta,':v_pedad',$edad);
    $clob = oci_new_descriptor($c,OCI_D_LOB);
    oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
    oci_execute($consulta,OCI_DEFAULT);
    if (isset($clob)) {
      $json = $clob->read($clob->size());
      echo $json;
    }else{
      echo 0;
    }
    oci_close($c);
  }
  function obtenerNombreIps(){
    require_once('../../config/dbcon.php');
    global $request;
    $ips = $request->ips;
    $consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_OBTENER_IPS(:v_pips,:v_json_row); end;');
    oci_bind_by_name($consulta,':v_pips',$ips);
    $clob = oci_new_descriptor($c,OCI_D_LOB);
    oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
    oci_execute($consulta,OCI_DEFAULT);
    if (isset($clob)) {
      $json = $clob->read($clob->size());
      echo $json;
    }else{
      echo 0;
    }
    oci_close($c);
  }
  function obtenerProducto(){   
    require_once('../../config/dbcon.php');
    global $request;
    $regimen = $request->regimen;
    $contrato = $request->contrato;
    $producto = $request->producto;
    $clasificacion = $request->clasificacion;
    $ubicacion = $request->ubicacion;
    $tipo = $request->tipo;
    $edad = $request->edad;
    $sexo = $request->sexo;
    $consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_OBTENER_PRODUCTO(:v_pcodigo,:v_pclasificacion,:v_pregimen,:v_pcontrato,:v_pprogramada,:v_pedad, :v_psexo,:v_json_row); end;');
    oci_bind_by_name($consulta,':v_pregimen',$regimen);
    oci_bind_by_name($consulta,':v_pcontrato',$contrato);
    oci_bind_by_name($consulta,':v_pcodigo',$producto);
    oci_bind_by_name($consulta,':v_pclasificacion',$clasificacion);
    oci_bind_by_name($consulta,':v_pprogramada',$tipo);
    oci_bind_by_name($consulta,':v_pedad',$edad);
    oci_bind_by_name($consulta,':v_psexo',$sexo);     
    $clob = oci_new_descriptor($c,OCI_D_LOB);
    oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
    oci_execute($consulta,OCI_DEFAULT);
    if (isset($clob)) {
      $json = $clob->read($clob->size());
      echo $json;
    }else{
      echo 0;
    }
    oci_close($c);
    
  }
  function insertarSolicitud(){
    require_once('../../config/dbcon.php');
    global $request;
    $data = json_decode($request->solicitud);    
    $consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_UI_AUTPRO(:v_pubicacion,
																					                        :v_ptipo_documento_afiliado,
																					                        :v_pdocumento_afiliado,
																																	:v_pcorreo_afiliado,
																																	:v_pcelular_afiliado,
																					                        :v_pdiagnostico_ppal,
																					                        :v_pdiagnostico_sec,
																					                        :v_pcod_servicio,
																					                        :v_pfecha_orden,
																					                        :v_pjustificacion,
																					                        :v_pnit,
																					                        :v_pnit_solicitante,
																					                        :v_presponsable,
																																	:v_pcontrato,
																																	:v_pcontratodocumento,
																																	:v_pcontratoubicacion,
																					                        :v_json_row); end;');
    oci_bind_by_name($consulta,':v_pubicacion',$data->ubicacion);
    oci_bind_by_name($consulta,':v_ptipo_documento_afiliado',$data->tipodocumento);
    oci_bind_by_name($consulta,':v_pdocumento_afiliado',$data->documento);
		oci_bind_by_name($consulta,':v_pcorreo_afiliado',$data->email);
		oci_bind_by_name($consulta,':v_pcelular_afiliado',$data->celular);
    oci_bind_by_name($consulta,':v_pdiagnostico_ppal',$data->diagcod1);
    oci_bind_by_name($consulta,':v_pdiagnostico_sec',$data->diagcod2);
    oci_bind_by_name($consulta,':v_pcod_servicio',$data->codservicio);
    oci_bind_by_name($consulta,':v_pfecha_orden',$data->fecsolicitudparseada);
    oci_bind_by_name($consulta,':v_pjustificacion',$data->justificacion);
    oci_bind_by_name($consulta,':v_pnit',$data->ipscodasignada);
    oci_bind_by_name($consulta,':v_pnit_solicitante',$data->ipscodsolicitante);
    oci_bind_by_name($consulta,':v_presponsable',$_SESSION['cedula']);
		oci_bind_by_name($consulta,':v_pcontrato',$data->contrato);
		oci_bind_by_name($consulta,':v_pcontratodocumento',$data->contratoDocumento);
		oci_bind_by_name($consulta,':v_pcontratoubicacion',$data->contratoUbicacion);
    $clob = oci_new_descriptor($c,OCI_D_LOB);
    oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
    oci_execute($consulta,OCI_COMMIT_ON_SUCCESS);
    if (isset($clob)) {
      $json = $clob->read($clob->size());
      echo $json;
    }else{
      echo 0;
    }
    oci_close($c);
  }
	function insertarDetalle(){
		require_once('../../config/dbcon.php');
		global $request;
		$productos = $request->productos;
		$cantidad = $request->cantidad;
		$numero = $request->numero;
		$ubicacion = $request->ubicacion;
		$consulta = oci_parse($c, 'BEGIN PQ_GENESIS_AUTPRO.P_INSERTAR_PRODUCTO(:v_pproductos,
																																	 				 :v_pcantidad,
																																	 				 :v_pnumero,
																																	 				 :v_pubicacion,
																																	 				 :v_pjson_row); end;');
		$jsonproductos = oci_new_descriptor($c, OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_pproductos', $jsonproductos, -1, OCI_B_CLOB);
		$jsonproductos->writeTemporary($productos);
		oci_bind_by_name($consulta,':v_pcantidad',$cantidad);
		oci_bind_by_name($consulta,':v_pnumero',$numero);
		oci_bind_by_name($consulta,':v_pubicacion',$ubicacion);
		$clob = oci_new_descriptor($c,OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_pjson_row', $clob,-1,OCI_B_CLOB);
		oci_execute($consulta,OCI_COMMIT_ON_SUCCESS);
		if (isset($clob)) {
			$json = $clob->read($clob->size());
			echo $json;
		}else{
			echo 0;
		}
		oci_close($c);
	}
	function ConsultarAfiliado(){
		require_once('../../config/dbcon.php');
		global $request;
		$tipo = $request->tipo;
		$numero = $request->numero;
		$consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_OBTENER_INFORMACION_BASICA_AFILIADO(:v_ptipodocumento,:v_pdocumento,:v_json_row); end;');
		oci_bind_by_name($consulta,':v_ptipodocumento',$tipo);
		oci_bind_by_name($consulta,':v_pdocumento',$numero);
		$clob = oci_new_descriptor($c,OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
		oci_execute($consulta,OCI_DEFAULT);
		if (isset($clob)) {
			$json = $clob->read($clob->size());
			echo $json;
		}else{
			echo 0;
		}
		oci_close($c);
	}
  function obtenerafiliados(){
      require_once('../../config/dbcon.php');
      global $request;
      $tipodocumento = $request->tipodocumento;
      $documento     = $request->documento;
      $consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_OBTENER_DATOS_BASICOS(:v_ptipodocumento,:v_pdocumento,:v_json_row); end;');
      oci_bind_by_name($consulta,':v_ptipodocumento',$tipodocumento);
      oci_bind_by_name($consulta,':v_pdocumento',$documento);
      $clob = oci_new_descriptor($c,OCI_D_LOB);
      oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
      oci_execute($consulta,OCI_DEFAULT);
      if (isset($clob)) {
        $json = $clob->read($clob->size());
        echo $json;
      }else{
        echo 0;
      }
      oci_close($c);
  }
  function obtenerTutelas(){
      require_once('../../config/dbcon.php');
      global $request;
      $tipodocumento = $request->tipodocumento;
      $documento     = $request->documento;
      $consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_OBTENER_TUTELA(:v_ptipodocumento,:v_pdocumento,:v_json_row); end;');
      oci_bind_by_name($consulta,':v_ptipodocumento',$tipodocumento);
      oci_bind_by_name($consulta,':v_pdocumento',$documento);
      $clob = oci_new_descriptor($c,OCI_D_LOB);
      oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
      oci_execute($consulta,OCI_DEFAULT);
      if (isset($clob)) {
        $json = $clob->read($clob->size());
        echo $json;
      }else{
        echo 0;
      }
      oci_close($c);
  }
  function obtenerSiniestro(){
      require_once('../../config/dbcon.php');
      global $request;
      $tipodocumento = $request->tipodocumento;
      $documento     = $request->documento;
      $consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_OBTENER_SINIESTRO(:v_ptipodocumento,:v_pdocumento,:v_json_row); end;');
      oci_bind_by_name($consulta,':v_ptipodocumento',$tipodocumento);
      oci_bind_by_name($consulta,':v_pdocumento',$documento);
      $clob = oci_new_descriptor($c,OCI_D_LOB);
      oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
      oci_execute($consulta,OCI_DEFAULT);
      if (isset($clob)) {
        $json = $clob->read($clob->size());
        echo $json;
      }else{
        echo 0;
      }
      oci_close($c);
  }
  function obtenerAutorizaciones(){
      require_once('../../config/dbcon.php');
      global $request;
      $documento = $request->documento;
      $numero     = $request->numero;
      $ubicacion     = $request->ubicacion;
      $consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_OBTENER_AUTORIZACIONES_DEMO(:v_pdocumento,:v_pnumero,:v_pubicacion,:v_json_row); end;');
      oci_bind_by_name($consulta,':v_pdocumento',$documento);
      oci_bind_by_name($consulta,':v_pnumero',$numero);
      oci_bind_by_name($consulta,':v_pubicacion',$ubicacion);
      $clob = oci_new_descriptor($c,OCI_D_LOB);
      oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
      oci_execute($consulta,OCI_DEFAULT);
      if (isset($clob)) {
        $json = $clob->read($clob->size());
        echo $json;
      }else{
        echo 0;
      }
      oci_close($c);
  }
  function ProcesaAnulaAutorizacion(){
      require_once('../../config/dbcon.php');
      global $request;
      $documento = 'AS';
      $numero    = $request->numero;
      $ubicacion = $request->ubicacion;
      $empresa   = 1;
      $operacion = $request->operacion;
      $consulta  = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.p_confirma_aut_sal_json(:v_pempresa,
                                                                                 :v_pdocumento,
                                                                                 :v_pnumero,
                                                                                 :v_pubicacion,
                                                                                 :v_poperacion,
                                                                                 :v_pjson_row); end;');
      oci_bind_by_name($consulta,':v_pempresa',$empresa);
      oci_bind_by_name($consulta,':v_pdocumento',$documento);
      oci_bind_by_name($consulta,':v_pnumero',$numero);
      oci_bind_by_name($consulta,':v_pubicacion',$ubicacion);
      oci_bind_by_name($consulta,':v_poperacion',$operacion);
      $clob = oci_new_descriptor($c,OCI_D_LOB);
      oci_bind_by_name($consulta, ':v_pjson_row', $clob,-1,OCI_B_CLOB);
      oci_execute($consulta,OCI_DEFAULT);
      if (isset($clob)) {
        $json = $clob->read($clob->size());
        echo $json;
      }else{
        echo 0;
      }
      oci_close($c);
  }

  function BuscarProducto(){
    require_once('../../config/dbcon.php');
    global $request;
    $coincidencia   = $request->coincidencia;
    $consulta  = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_BUSCAR_PRODUCTOS(:v_pcoincidencia,
                                                                          :v_pjson_row); end;');
    oci_bind_by_name($consulta,':v_pcoincidencia',$coincidencia);
    $clob = oci_new_descriptor($c,OCI_D_LOB);
    oci_bind_by_name($consulta, ':v_pjson_row', $clob,-1,OCI_B_CLOB);
    oci_execute($consulta,OCI_DEFAULT);
    if (isset($clob)) {
      $json = $clob->read($clob->size());
      echo $json;
    }else{
      echo 0;
    }
    oci_close($c);
  }
  function ObtenerEspecialidades(){
      require_once('../../config/dbcon.php');
      global $request;
      $consulta  = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_OBTENER_ESPECIALIDADES(:v_json_row); end;');
      $clob = oci_new_descriptor($c,OCI_D_LOB);
      oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
      oci_execute($consulta,OCI_DEFAULT);
      if (isset($clob)) {
        $json = $clob->read($clob->size());
        echo $json;
      }else{
        echo 0;
      }
      oci_close($c);
    }
  function insertarDetalleAut(){
    require_once('../../config/dbcon.php');
    global $request;
    $productos = $request->productos;
    $cantidad = $request->cantidad;
    $numero = $request->numero;
    $ubicacion = $request->ubicacion;
    $documento = 'AS';
    $consulta = oci_parse($c, 'BEGIN PQ_GENESIS_AUTPRO.P_UI_DETALLE_AUT_WEB(:v_pproductos,
                                                                                :v_pcantidad,
                                                                                :v_pdocumento,
                                                                                :v_pnumero,
                                                                                :v_pubicacion,
                                                                                :v_pjson_row); end;');
    $jsonproductos = oci_new_descriptor($c, OCI_D_LOB);
    oci_bind_by_name($consulta, ':v_pproductos', $jsonproductos, -1, OCI_B_CLOB);
    $jsonproductos->writeTemporary($productos);
    oci_bind_by_name($consulta,':v_pcantidad',$cantidad);
    oci_bind_by_name($consulta,':v_pdocumento',$documento);
    oci_bind_by_name($consulta,':v_pnumero',$numero);
    oci_bind_by_name($consulta,':v_pubicacion',$ubicacion);
    $clob = oci_new_descriptor($c,OCI_D_LOB);
    oci_bind_by_name($consulta, ':v_pjson_row', $clob,-1,OCI_B_CLOB);
    oci_execute($consulta,OCI_COMMIT_ON_SUCCESS);
    if (isset($clob)) {
      $json = $clob->read($clob->size());
      echo $json;
    }else{
      echo 0;
    }
    oci_close($c);
  }

  function insertarAutorizacion(){
    require_once('../../config/dbcon.php');
    global $request;
    $data = json_decode($request->autorizacion);
    $documento  = 'AS';
    $valdefecto = 0;
    $ubicacion="";
    $fuente='G';

     if($data->numero=='0') {
        $valdefecto = 0;
     }else{
        $valdefecto = $data->numero;
    }
    
    if ($data->accion=='U') {
       $ubicacion= $data->ubicacion;
    }else{
      $ubicacion=$data->ubicacion;
    }

    $consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_UI_CABEZA_AUT_WEB(:v_pdocumento,
                                                               :v_pnumero,
                                                               :v_pubicacion,
                                                               :v_pubicacion_contrato,
                                                               :v_pdocumento_contrato,
                                                               :v_ptipo_doc_afiliado,
                                                               :v_pdocumento_afiliado,
                                                               :v_pclasificacion,
                                                               :v_ptipo,
                                                               :v_palto_costo,
                                                               :v_patencion,
                                                               :v_pproveedor,
                                                               :v_pobservacion,
                                                               :v_pdiagnostico,
                                                               :v_pdiagnostico1,
                                                               :v_pclase,
                                                               :v_pprograma,
                                                               :v_pcontrato_prestacion,
                                                               :v_pubicacion_solicitud,
                                                               :v_pacta_tutela,
                                                               :v_psolicitante,
                                                               :v_psiniestro,
                                                               :v_porigen,
                                                               :v_ptipo_solicitud,
                                                               :v_pprioridad,
                                                               :v_pdireccion,
                                                               :v_pnombre_medico,
                                                               :v_pespecialidad_medico,
                                                               :v_panticipo,
                                                               :v_pctc,
                                                               :v_porden,
                                                               :v_pmipres,
                                                               :v_paccion,
                                                               :v_fuente,
                                                               :v_pano_pss,
                                                               :v_pmes_pss,
                                                               :v_pnumero_a,
                                                               : v_ubicacion_a,                                                                                                                                            
                                                               :v_pjson_row); end;');

    oci_bind_by_name($consulta,':v_pdocumento',$documento);
    oci_bind_by_name($consulta,':v_pnumero',$valdefecto);
    oci_bind_by_name($consulta,':v_pubicacion', $ubicacion);
    oci_bind_by_name($consulta,':v_pubicacion_contrato',$data->ubicacioncontrato);
    oci_bind_by_name($consulta,':v_pdocumento_contrato',$data->documentocontrato);
    oci_bind_by_name($consulta,':v_ptipo_doc_afiliado',$data->tipodocumento);
    oci_bind_by_name($consulta,':v_pdocumento_afiliado',$data->documento);
    oci_bind_by_name($consulta,':v_pclasificacion',$data->codservicio);
    oci_bind_by_name($consulta,':v_ptipo',$data->valortipo);
    oci_bind_by_name($consulta,':v_palto_costo',$data->altocosto);
    oci_bind_by_name($consulta,':v_patencion',$data->origen);
    oci_bind_by_name($consulta,':v_pproveedor',$data->ipscodasignada);
    oci_bind_by_name($consulta,':v_pobservacion',$data->observacion);
    oci_bind_by_name($consulta,':v_pdiagnostico',$data->diagcod1);
    oci_bind_by_name($consulta,':v_pdiagnostico1',$data->diagcod2);
    oci_bind_by_name($consulta,':v_pclase',$data->valornopos);
    oci_bind_by_name($consulta,':v_pprograma',$valdefecto);
    oci_bind_by_name($consulta,':v_pcontrato_prestacion',$data->contrato);
    oci_bind_by_name($consulta,':v_pubicacion_solicitud',$data->ubicacionpaciente);
    oci_bind_by_name($consulta,':v_pacta_tutela',$data->valortutela);
    oci_bind_by_name($consulta,':v_psolicitante',$data->ipscodsolicita);
    oci_bind_by_name($consulta,':v_psiniestro',$data->valorsiniestro);
    oci_bind_by_name($consulta,':v_porigen',$data->origen);
    oci_bind_by_name($consulta,':v_ptipo_solicitud',$data->tiposervicio);
    oci_bind_by_name($consulta,':v_pprioridad',$data->valorprioridad);
    oci_bind_by_name($consulta,':v_pdireccion',$data->ipsasignadadireccion);
    oci_bind_by_name($consulta,':v_pnombre_medico',$data->nombremedico);
    oci_bind_by_name($consulta,':v_pespecialidad_medico',$data->codespecialidad);
    oci_bind_by_name($consulta,':v_panticipo',$data->valoranticipo);
    oci_bind_by_name($consulta,':v_pctc',$data->valortutela);
    oci_bind_by_name($consulta,':v_porden',$data->fechasolicitudparseada);
    oci_bind_by_name($consulta,':v_pmipres',$data->valormipres);
    oci_bind_by_name($consulta,':v_paccion',$data->accion);
    oci_bind_by_name($consulta,':v_fuente',$fuente);
    oci_bind_by_name($consulta,':v_pano_pss',$data->anopass);
    oci_bind_by_name($consulta,':v_pmes_pss',$data->mespess);   
    oci_bind_by_name($consulta,':v_pnumero_a',$data->codaut);
    oci_bind_by_name($consulta,':v_ubicacion_a',$data->ubiaut);      
    $clob = oci_new_descriptor($c,OCI_D_LOB);
    oci_bind_by_name($consulta, ':v_pjson_row', $clob,-1,OCI_B_CLOB);
    oci_execute($consulta,OCI_COMMIT_ON_SUCCESS);
    if (isset($clob)) {
      $json = $clob->read($clob->size());
      echo $json;
    }else{
      echo $clob;
    }
    oci_close($c);
  }
  function insertarAutorizacionEntregas(){
    require_once('../../config/dbcon.php');
    global $request;
    $data = json_decode($request->autorizacion);
    $jsonproductos = json_decode($request->productos);
    $consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_INSERTAR_PRODUCTO_MED(:v_pautorizacion,
                                                               :v_pproductos,
                                                               :v_pcantproducto,                                                                                                                                                                                                                                                           
                                                               :v_pjson_row); end;');

    $aut = oci_new_descriptor($c, OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_pautorizacion', $aut, -1, OCI_B_CLOB);
    $aut->writeTemporary($request->autorizacion);     
    $jsonproductos = oci_new_descriptor($c, OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_pproductos', $jsonproductos, -1, OCI_B_CLOB);
		$jsonproductos->writeTemporary($request->productos);     
    $clob = oci_new_descriptor($c,OCI_D_LOB);    
    oci_bind_by_name($consulta,':v_pcantproducto',$request->cantidad);
    oci_bind_by_name($consulta, ':v_pjson_row', $clob,-1,OCI_B_CLOB);
    oci_execute($consulta,OCI_COMMIT_ON_SUCCESS);
    if (isset($clob)) {
      $json = $clob->read($clob->size());
      echo $json;
    }else{
      echo $clob;
    }
    oci_close($c);
  }
  
  function obtenerDetalleAut(){
    require_once('../../config/dbcon.php');
    global $request;
    $producto = $request->producto;
    $ubicacion = $request->ubicacion;
    $consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_OBTENER_DETALLE_AUT(:v_pnumero,:v_pubicacion,:v_json_row); end;');
    oci_bind_by_name($consulta,':v_pnumero',$producto);
    oci_bind_by_name($consulta,':v_pubicacion',$ubicacion);
    $clob = oci_new_descriptor($c,OCI_D_LOB);
    oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
    oci_execute($consulta,OCI_DEFAULT);
    if (isset($clob)) {
      $json = $clob->read($clob->size());
      echo $json;
    }else{
      echo 0;
    }
    oci_close($c);
  }

  //=================== NUEVO =================//

  function obtener_Uautorizaciones(){
		require_once('../../config/dbcon.php');
		global $request;
		$numero = $request->numero;
    $ubicacion = $request->ubicacion;
		$consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_U_AUTORIZACIONES(:v_pnumero,:v_pubicacion,:v_json_row); end;');
		oci_bind_by_name($consulta,':v_pnumero',$numero);
    oci_bind_by_name($consulta,':v_pubicacion',$ubicacion);
		$clob = oci_new_descriptor($c,OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
		oci_execute($consulta,OCI_DEFAULT);
		if (isset($clob)) {
			$json = $clob->read($clob->size());
			echo $json;
		}else{
			echo 0;
		}
		oci_close($c);
  }
  function obtener_novedades(){
		require_once('../../config/dbcon.php');
		global $request;
		$documento = $request->documento;
    $tipodocumento = $request->tipodocumento;
		$consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_OBTENER_NOVEDADES(:v_pdocumento,:v_ptipodocumento,:v_pjson_row); end;');
		oci_bind_by_name($consulta,':v_pdocumento',$documento);
    oci_bind_by_name($consulta,':v_ptipodocumento',$tipodocumento);
		$clob = oci_new_descriptor($c,OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_pjson_row', $clob,-1,OCI_B_CLOB);
		oci_execute($consulta,OCI_DEFAULT);
		if (isset($clob)) {
			$json = $clob->read($clob->size());
			echo $json;
		}else{
			echo 0;
		}
		oci_close($c);
  }
  function obtener_detalle_programada(){
		require_once('../../config/dbcon.php');
		global $request;
		$numero = $request->numero;
    $ubicacion = $request->ubicacion;
		$consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_OBTENER_DETALLE_PROGRAMADA(:v_pnumero,:v_pubicacion,:v_json_row); end;');
		oci_bind_by_name($consulta,':v_pnumero',$numero);
    oci_bind_by_name($consulta,':v_pubicacion',$ubicacion);
		$clob = oci_new_descriptor($c,OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
		oci_execute($consulta,OCI_DEFAULT);
		if (isset($clob)) {
			$json = $clob->read($clob->size());
			echo $json;
		}else{
			echo 0;
		}
		oci_close($c);
  }

  function obtener_capita (){
    require_once('../../config/dbcon.php');
		global $request;
		$tipo = $request->tipodocumento;
    $documento = $request->documento;
		$consulta = oci_parse($c,'BEGIN pq_genesis_ca.p_mostrar_escenarios(:v_ptipo_documento,:v_pdocumento,:v_json_row); end;');
		oci_bind_by_name($consulta,':v_ptipo_documento',$tipo);
    oci_bind_by_name($consulta,':v_pdocumento',$documento);
		$clob = oci_new_descriptor($c,OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
		oci_execute($consulta,OCI_DEFAULT);
		if (isset($clob)) {
			$json = $clob->read($clob->size());
			echo $json;
		}else{
			echo 0;
		}
		oci_close($c);
  }
  function obtener_especialidad (){
    require_once('../../config/dbcon.php');
		global $request;
		$nit = $request->nit;
		$consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_LISTA_ESPECIALIDAD(:v_pnit,:v_json_row); end;');
		oci_bind_by_name($consulta,':v_pnit',$nit);
		$clob = oci_new_descriptor($c,OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
		oci_execute($consulta,OCI_DEFAULT);
		if (isset($clob)) {
			$json = $clob->read($clob->size());
			echo $json;
		}else{
			echo 0;
		}
		oci_close($c);
  }
  function obtener_soportes(){
    require_once('../../config/dbcon.php');
		global $request;
    $tipo = $request->tipodocumento;
    $documento = $request->documento;
		$consulta = oci_parse($c,'BEGIN pq_genesis_ca.p_mostrar_soporte_doc(:v_ptipo_documento,:v_pdocumento,:v_json_row); end;');
    oci_bind_by_name($consulta,':v_ptipo_documento',$tipo);
    oci_bind_by_name($consulta,':v_pdocumento',$documento);
    
		$clob = oci_new_descriptor($c,OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
		oci_execute($consulta,OCI_DEFAULT);
		if (isset($clob)) {
			$json = $clob->read($clob->size());
			echo $json;
		}else{
			echo 0;
		}
		oci_close($c);
  }


  function subirArchivoAut(){
    require_once('../../config/dbcon_prod.php');
    require_once('../../upload_file/subir_archivo.php');
    global $request;	
        if ($request->ext) {
          $file = $request->file;
          $ext = $request->ext;
          $numero = $request->num;
          $ubicacion = $request->ubicacion;                    
          $arhivo =  'AUT'.'-'. $numero .'-'. $ubicacion;		
          $path = '/cargue_ftp/Digitalizacion/Genesis/Autorizaciones/Web/';
  
          $subir = subirFTP($file,$path,$arhivo,$ext);
          
  
        }else{
         echo 'Extension vacia';
        }
        if ($subir) {
          echo $subir;
        }         
  }  


  function insertarAdjunto(){
    require_once('../../config/dbcon.php');
    global $request;
    $documento  = 'AS';  
    $consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_I_ADJUNTO_EAUT(:v_pdocumento,
                                                                      :v_pnumero,        
                                                                      :v_pubicacion,
                                                                      :v_padjunto, 
                                                                      :v_pcantidad,
                                                                      :v_pjson_row); end;');
    oci_bind_by_name($consulta,':v_pdocumento',$documento);
    oci_bind_by_name($consulta,':v_pnumero',$request->num);
    oci_bind_by_name($consulta,':v_pubicacion',$request->ubicacion);
    $adjuntoaut = oci_new_descriptor($c, OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_padjunto', $adjuntoaut, -1, OCI_B_CLOB);
    $adjuntoaut->writeTemporary($request->file); 
    oci_bind_by_name($consulta,':v_pcantidad',$request->cantidad);
    $clob = oci_new_descriptor($c,OCI_D_LOB);
    oci_bind_by_name($consulta, ':v_pjson_row', $clob,-1,OCI_B_CLOB);
    oci_execute($consulta,OCI_COMMIT_ON_SUCCESS);
    if (isset($clob)) {
      $json = $clob->read($clob->size());
      echo $json;
    }else{
      echo $clob;
    }
    oci_close($c);
  }

  function acualizarAdjunto(){
    require_once('../../config/dbcon.php');
    global $request;
    $documento  = 'AS';  
    $consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_U_ADJUNTO_EAUT(:v_pdocumento,
                                                                       :v_pnumero,         
                                                                       :v_pubicacion,
                                                                       :v_pcodigo_adj,
                                                                       :v_pruta_adj,
                                                                       :v_pjson_row); end;');
    oci_bind_by_name($consulta,':v_pdocumento',$documento);
    oci_bind_by_name($consulta,':v_pnumero',$request->num);
    oci_bind_by_name($consulta,':v_pubicacion',$request->ubicacion);    
		oci_bind_by_name($consulta,':v_pcodigo_adj',$request->codadjunto);    
    oci_bind_by_name($consulta,':v_pruta_adj',$request->ruta);
    $clob = oci_new_descriptor($c,OCI_D_LOB);
    oci_bind_by_name($consulta, ':v_pjson_row', $clob,-1,OCI_B_CLOB);
    oci_execute($consulta,OCI_COMMIT_ON_SUCCESS);
    if (isset($clob)) {
      $json = $clob->read($clob->size());
      echo $json;
    }else{
      echo $clob;
    }
    oci_close($c);
  }

  function obtener_aut_anuladas (){
    require_once('../../config/dbcon.php');
    global $request;
    $tipo = $request->tipodocumento;  
    $documento = $request->documento; 
    $nit = $request->nit;  
		$consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_LISTA_AUTORIZACIONES_ANULADAS(:v_ptipodocumento,:v_pdocumento,:v_pnit,:v_json_row); end;');
    oci_bind_by_name($consulta,':v_ptipodocumento',$tipo);
    oci_bind_by_name($consulta,':v_pdocumento',$documento);
    oci_bind_by_name($consulta,':v_pnit',$nit);
		$clob = oci_new_descriptor($c,OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
		oci_execute($consulta,OCI_DEFAULT);
		if (isset($clob)) {
			$json = $clob->read($clob->size());
			echo $json;
		}else{
			echo 0;
		}
		oci_close($c);
  }

 
  function listaProducto(){   
    require_once('../../config/dbcon.php');
    global $request;
    $regimen = $request->regimen;
    $contrato = $request->contrato;
    $clasificacion = $request->clasificacion;
    $edad = $request->edad;
    $sexo = $request->sexo;
    $consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_lista_productos(:v_pclasificacion,:v_pregimen,:v_pcontrato,:v_pedad, :v_psexo,:v_json_row); end;');
    oci_bind_by_name($consulta,':v_pregimen',$regimen);
    oci_bind_by_name($consulta,':v_pcontrato',$contrato);  
    oci_bind_by_name($consulta,':v_pclasificacion',$clasificacion);    
    oci_bind_by_name($consulta,':v_pedad',$edad);
    oci_bind_by_name($consulta,':v_psexo',$sexo);     
    $clob = oci_new_descriptor($c,OCI_D_LOB);
    oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
    oci_execute($consulta,OCI_DEFAULT);
    if (isset($clob)) {
      $json = $clob->read($clob->size());
      echo $json;
    }else{
      echo 0;
    }
    oci_close($c);
    
  }
  function obtener_techo (){
    require_once('../../config/dbcon.php');
		global $request;
    $anno = $request->anno;
    $periodo = $request->periodo;
		$consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_OBTENER_TECHO(:v_panno,:v_pperiodo,:v_pjson_row); end;');
    oci_bind_by_name($consulta,':v_panno',$anno);
    oci_bind_by_name($consulta,':v_pperiodo',$periodo);
		$clob = oci_new_descriptor($c,OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_pjson_row', $clob,-1,OCI_B_CLOB);
		oci_execute($consulta,OCI_DEFAULT);
		if (isset($clob)) {
			$json = $clob->read($clob->size());
			echo $json;
		}else{
			echo 0;
		}
		oci_close($c);
  }
  function actualizar_techo (){
    require_once('../../config/dbcon.php');
		global $request;
    $seccional = $request->seccional;
    $anno = $request->anno;
    $valor = $request->valor;
    $accion = $request->accion;
    $periodo = $request->periodo;
		$consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_ACTUALIZA_TECHO(:v_pseccional,:v_panno,:v_pperiodo,:v_pvalor, :v_paccion,:v_pjson_row); end;');
    oci_bind_by_name($consulta,':v_pseccional',$seccional);
    oci_bind_by_name($consulta,':v_panno',$anno);
    oci_bind_by_name($consulta,':v_pperiodo',$periodo);
    oci_bind_by_name($consulta,':v_pvalor',$valor);
    oci_bind_by_name($consulta,':v_paccion',$accion);
		$clob = oci_new_descriptor($c,OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_pjson_row', $clob,-1,OCI_B_CLOB);
		oci_execute($consulta,OCI_DEFAULT);
		if (isset($clob)) {
			$json = $clob->read($clob->size());
			echo $json;
		}else{
			echo 0;
		}
		oci_close($c);
  }
  function obtener_detalle_techo (){
    require_once('../../config/dbcon.php');
    global $request;
    $seccional = $request->seccional;
    $anno = $request->anno;
    $periodo = $request->periodo;
		$consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_OBTENER_AUD_TECHO(:v_pseccional,:v_panno,:v_pperiodo,:v_pjson_row); end;');
    oci_bind_by_name($consulta,':v_pseccional',$seccional);
    oci_bind_by_name($consulta,':v_panno',$anno);      
    oci_bind_by_name($consulta,':v_pperiodo',$periodo);
		$clob = oci_new_descriptor($c,OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_pjson_row', $clob,-1,OCI_B_CLOB);
		oci_execute($consulta,OCI_DEFAULT);
		if (isset($clob)) {
			$json = $clob->read($clob->size());
			echo $json;
		}else{
			echo 0;
		}
		oci_close($c);
  }

  function obtener_seccionales_aut_activas (){
    require_once('../../config/dbcon.php');
    global $request;
    $seccional = $request->sessional;  
		$consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_LISTA_MUN_AUTORIZACIONES_ACTIVAS_2(:v_pseccional,:v_json_row); end;');
    oci_bind_by_name($consulta,':v_pseccional',$seccional);
		$clob = oci_new_descriptor($c,OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
		oci_execute($consulta,OCI_DEFAULT);
		if (isset($clob)) {
			$json = $clob->read($clob->size());
			echo $json;
		}else{
			echo 0;
		}
		oci_close($c);
  }
  function obtener_aut_activas (){
    require_once('../../config/dbcon.php');
    global $request;
    $seccional = $request->sessional;  
		$consulta = oci_parse($c,'BEGIN PQ_GENESIS_AUTPRO.P_LISTA_AUTORIZACIONES_ACTIVAS_2(:v_pseccional,:v_json_row); end;');
    oci_bind_by_name($consulta,':v_pseccional',$seccional);
		$clob = oci_new_descriptor($c,OCI_D_LOB);
		oci_bind_by_name($consulta, ':v_json_row', $clob,-1,OCI_B_CLOB);
		oci_execute($consulta,OCI_DEFAULT);
		if (isset($clob)) {
			$json = $clob->read($clob->size());
			echo $json;
		}else{
			echo 0;
		}
		oci_close($c);
  }
 
?>
